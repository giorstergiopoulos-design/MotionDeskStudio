using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using MotionDesk.Services;
using MotionDesk.Widgets;
using System.Diagnostics;

namespace MotionDesk.UI
{
    /// <summary>
    /// The real application shell. Feature windows/widgets remain independent,
    /// while this window provides a single navigation point for the desktop manager.
    /// </summary>
    public sealed class MainWindow : Form
    {
        private readonly Panel _content;
        private readonly Label _pageTitle;
        private readonly ToolStripStatusLabel _statusLabel;
        private readonly System.Windows.Forms.Timer _statusTimer;
        private Button? _activeButton;
        private readonly HotkeyManager _hotkeys;

        public MainWindow()
        {
            var appSettings = AppSettings.Load();
            WidgetSnapEngine.EnableGridSnap = appSettings.GridSnap;
            WidgetSnapEngine.SnapThreshold = Math.Clamp(appSettings.SnapThreshold, 5, 50);
            WidgetSnapEngine.GridSize = Math.Clamp(appSettings.GridSize, 5, 100);
            Text = "MotionDesk Studio";
            Icon = LoadApplicationIcon();
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(900, 580);
            Size = new Size(1080, 680);
            BackColor = Color.FromArgb(18, 18, 20);
            ForeColor = Color.White;

            var sidebar = new Panel
            {
                Dock = DockStyle.Left,
                Width = 210,
                BackColor = Color.FromArgb(25, 25, 28),
                Padding = new Padding(14)
            };

            var brand = new Label
            {
                Dock = DockStyle.Top,
                Height = 72,
                Text = "MotionDesk\nStudio",
                Font = new Font("Segoe UI", 18f, FontStyle.Bold),
                ForeColor = Color.White,
                Padding = new Padding(8, 6, 0, 0)
            };
            sidebar.Controls.Add(brand);

            var nav = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true,
                Padding = new Padding(0, 10, 0, 0)
            };
            sidebar.Controls.Add(nav);

            AddNavButton(nav, "Dashboard", ShowDashboard);
            AddNavButton(nav, "Widgets", ShowWidgets);
            AddNavButton(nav, "DeskZones", ShowDeskZones);
            AddNavButton(nav, "Wallpaper", ShowWallpaper);
            AddNavButton(nav, "System Monitor", ShowMonitor);
            AddNavButton(nav, "Settings", ShowSettings);
            AddNavButton(nav, "Profiles", ShowProfiles);
            AddNavButton(nav, "Performance", ShowPerformance);
            AddNavButton(nav, "Automation", ShowAutomation);
            AddNavButton(nav, "About", ShowAbout);

            _content = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(18, 18, 20),
                Padding = new Padding(28)
            };

            var header = new Panel { Dock = DockStyle.Top, Height = 58 };
            _pageTitle = new Label
            {
                Dock = DockStyle.Fill,
                Text = "Dashboard",
                Font = new Font("Segoe UI", 22f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            };
            header.Controls.Add(_pageTitle);

            var status = new StatusStrip
            {
                Dock = DockStyle.Bottom,
                SizingGrip = false,
                BackColor = Color.FromArgb(25, 25, 28)
            };
            _statusLabel = new ToolStripStatusLabel("MotionDesk ready")
            {
                Spring = true,
                TextAlign = ContentAlignment.MiddleLeft
            };
            status.Items.Add(_statusLabel);

            Controls.Add(_content);
            Controls.Add(header);
            Controls.Add(sidebar);
            Controls.Add(status);

            _statusTimer = new System.Windows.Forms.Timer { Interval = 5000 };
            _statusTimer.Tick += (_, _) => UpdateStatus();
            _statusTimer.Start();
            _hotkeys = new HotkeyManager();
            _hotkeys.RegisterCtrlAlt('G', ToggleGamingMode);
            _hotkeys.RegisterCtrlAlt('M', ShowAndActivate);
            FormClosed += (_, _) =>
            {
                try { WorkspaceProfileService.Save("Last Session"); } catch { }
                _statusTimer.Dispose();
                _hotkeys.Dispose();
            };

            ShowDashboard();
            var saved = AppSettings.Load();
            if (saved.RestoreLastSession && WorkspaceProfileService.ListProfiles().Contains("Last Session", StringComparer.OrdinalIgnoreCase))
            {
                try { WorkspaceProfileService.Load("Last Session"); } catch { }
            }
            else if (saved.ShowSystemMonitor && !WidgetHostEngine.Instance.GetActiveWidgets().Any(w => w.WidgetId == "sysmon"))
            {
                WidgetHostEngine.Instance.SpawnWidget("sysmon", 100, 100, 300, 200);
            }
            if (nav.Controls.Count > 0)
                SetActiveButton((Button)nav.Controls[0]);
        }

        private Button AddNavButton(Control parent, string text, Action action)
        {
            var button = new Button
            {
                Text = text,
                Width = 178,
                Height = 42,
                FlatStyle = FlatStyle.Flat,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(12, 0, 0, 0),
                ForeColor = Color.Gainsboro,
                BackColor = Color.FromArgb(25, 25, 28),
                Margin = new Padding(0, 0, 0, 6),
                TabStop = false
            };
            button.FlatAppearance.BorderSize = 0;
            button.Click += (_, _) => action();
            button.Click += (_, _) => SetActiveButton(button);
            parent.Controls.Add(button);
            return button;
        }

        private void SetActiveButton(Button button)
        {
            if (_activeButton != null)
            {
                _activeButton.BackColor = Color.FromArgb(25, 25, 28);
                _activeButton.ForeColor = Color.Gainsboro;
            }

            _activeButton = button;
            _activeButton.BackColor = Color.FromArgb(45, 45, 50);
            _activeButton.ForeColor = Color.White;
        }

        private void SetPage(string title, Control control)
        {
            _pageTitle.Text = title;
            _content.SuspendLayout();
            _content.Controls.Clear();
            control.Dock = DockStyle.Fill;
            _content.Controls.Add(control);
            _content.ResumeLayout();
        }

        private void ShowAndActivate()
        {
            if (WindowState == FormWindowState.Minimized)
                WindowState = FormWindowState.Normal;
            Show();
            BringToFront();
            Activate();
        }

        private void ShowDashboard()
        {
            var panel = CreatePagePanel();
            AddHeading(panel, "MotionDesk Studio");
            AddText(panel, "Το desktop σου, οργανωμένο σε ένα ελαφρύ workspace hub.");

            var metrics = SystemMonitorService.Instance.GetSnapshot();
            AddCard(panel, "System", $"CPU {metrics.CpuPercent:0.0}%   •   RAM {metrics.AvailableMemoryMb:0} / {metrics.TotalMemoryMb:0} MB free");
            AddCard(panel, "Desktop", $"{Screen.AllScreens.Length} monitor(s)   •   {WidgetHostEngine.Instance.GetActiveWidgets().Count} active widget(s)   •   {DeskZoneHostEngine.Instance.GetActiveZones().Count} zone(s)");
            AddCard(panel, "Wallpaper", $"{(WallpaperHostEngine.Instance.IsEnabled ? "ON" : "OFF")}   •   {WallpaperSettings.Load().PerformanceMode}");

            AddSection(panel, "Quick launch");
            AddButton(panel, "Open Widget Gallery", (_, _) => ShowWidgets());
            AddButton(panel, "Create DeskZone", (_, _) => { DeskZoneHostEngine.Instance.SpawnZone($"zone{DateTime.Now.Ticks}", "New DeskZone", 300, 120, 360, 240); _statusLabel.Text = "DeskZone created"; });
            AddButton(panel, "Enable Aurora Wallpaper", (_, _) => { WallpaperHostEngine.Instance.Enable(); _statusLabel.Text = "Wallpaper enabled"; });
            AddButton(panel, "Command Palette", (_, _) => ShowCommandPalette());

            AddSection(panel, "Workspace");
            AddButton(panel, "Work Profile", (_, _) => LoadProfileFromQuickButton("Work"));
            AddButton(panel, "Gaming Profile", (_, _) => LoadProfileFromQuickButton("Gaming"));
            AddButton(panel, "Focus Profile", (_, _) => LoadProfileFromQuickButton("Focus"));
            SetPage("Dashboard", panel);
        }

        private void ShowWidgets()
        {
            var panel = CreatePagePanel();
            AddHeading(panel, "Widget Gallery");
            AddText(panel, "Native widgets are lightweight. WebView2 is reserved for rich HTML/video widgets.");
            AddSection(panel, "Desktop widgets");
            AddButton(panel, "＋ System Monitor", (_, _) => WidgetHostEngine.Instance.SpawnWidget("sysmon", 100, 100, 320, 220));
            AddButton(panel, "＋ Clock", (_, _) => WidgetHostEngine.Instance.SpawnWidget("clock", 450, 100, 300, 220));
            AddButton(panel, "＋ Network", (_, _) => WidgetHostEngine.Instance.SpawnWidget("network", 100, 350, 320, 220));
            AddButton(panel, "＋ Audio Visualizer", (_, _) => WidgetHostEngine.Instance.SpawnWidget("audio", 450, 350, 300, 220));
            AddButton(panel, "＋ Weather", (_, _) => WidgetHostEngine.Instance.SpawnWidget("weather", 800, 100, 300, 220));
            AddSection(panel, "Workspace actions");
            AddButton(panel, "Save current widget layout", (_, _) => { WorkspaceProfileService.Save("Last Session"); _statusLabel.Text = "Widget layout saved"; });
            AddButton(panel, "Restore saved widget layout", (_, _) => { WorkspaceProfileService.Load("Last Session"); _statusLabel.Text = "Workspace restored"; });
            AddButton(panel, "Close all widgets", (_, _) => WidgetHostEngine.Instance.CloseAll());
            SetPage("Widgets", panel);
        }

        private void ShowDeskZones()
        {
            var panel = CreatePagePanel();
            AddHeading(panel, "DeskZones");
            AddText(panel, "Δημιούργησε ζώνες για να οργανώσεις το desktop σου. Οι θέσεις αποθηκεύονται και επανέρχονται.");
            AddSection(panel, "Layouts");
            AddButton(panel, "2 columns", (_, _) => CreateZoneLayout(2, 1));
            AddButton(panel, "3 columns", (_, _) => CreateZoneLayout(3, 1));
            AddButton(panel, "2 × 2 grid", (_, _) => CreateZoneLayout(2, 2));
            AddButton(panel, "3 × 2 grid", (_, _) => CreateZoneLayout(3, 2));
            AddButton(panel, "New custom zone", (_, _) => DeskZoneHostEngine.Instance.SpawnZone($"zone{DateTime.Now.Ticks}", "Custom Zone", 300, 120, 360, 240));
            AddSection(panel, "Actions");
            AddButton(panel, "Save current zones", (_, _) => { WorkspaceProfileService.Save("Last Session"); _statusLabel.Text = "DeskZones saved"; });
            AddButton(panel, "Restore saved zones", (_, _) => { WorkspaceProfileService.Load("Last Session"); _statusLabel.Text = "Workspace restored"; });
            AddButton(panel, "Close all zones", (_, _) => DeskZoneHostEngine.Instance.CloseAll());
            SetPage("DeskZones", panel);
        }

        private void ShowWallpaper()
        {
            var panel = CreatePagePanel();
            AddHeading(panel, "Wallpaper Studio");
            AddText(panel, "Live wallpaper με performance modes και automatic battery optimization.");
            var current = WallpaperSettings.Load();
            AddCard(panel, "Current video", string.IsNullOrWhiteSpace(current.VideoPath) ? "Aurora / default" : Path.GetFileName(current.VideoPath));
            AddButton(panel, "Enable", (_, _) => WallpaperHostEngine.Instance.Enable());
            AddButton(panel, "Disable", (_, _) => WallpaperHostEngine.Instance.Disable());
            AddButton(panel, "Choose video…", (_, _) => ChooseWallpaperVideo());
            AddButton(panel, "Clear video / Aurora", (_, _) => WallpaperHostEngine.Instance.ClearVideo());
            AddSection(panel, "Performance");
            foreach (var mode in new[] { "High", "Balanced", "Low Power", "Battery" })
                AddButton(panel, mode, (_, _) => WallpaperHostEngine.Instance.SetPerformanceMode(mode));
            SetPage("Wallpaper", panel);
        }

        private void ShowMonitor()
        {
            var panel = CreatePagePanel();
            AddHeading(panel, "System Monitor");
            AddText(panel, "Live hardware overview χωρίς PerformanceCounter ανά widget.");
            var cpu = AddCard(panel, "CPU", "");
            var ram = AddCard(panel, "Memory", "");
            var net = AddCard(panel, "Network", "");
            var extra = AddCard(panel, "Processes / Power", "");
            var timer = new System.Windows.Forms.Timer { Interval = 2000 };
            timer.Tick += (_, _) => {
                var m = AdvancedSystemMonitorService.Instance.GetSnapshot();
                cpu.Text = $"{m.CpuPercent:0.0}%";
                ram.Text = $"{m.AvailableMemoryMb:0} MB free / {m.TotalMemoryMb:0} MB";
                net.Text = $"↓ {m.NetworkDownKbps:0.0} KB/s   ↑ {m.NetworkUpKbps:0.0} KB/s";
                extra.Text = $"{m.ProcessCount} processes   •   recommended: {m.BatteryMode}";
            };
            timer.Start();
            panel.Disposed += (_, _) => timer.Dispose();
            SetPage("System Monitor", panel);
        }

        private void ShowSettings()
        {
            var settings = new SettingsView();
            SetPage("Settings", settings);
        }

        private void ShowCommandPalette()
        {
            using var dialog = new Form { Text = "MotionDesk Command Palette", StartPosition = FormStartPosition.CenterParent, Size = new Size(560, 430), BackColor = Color.FromArgb(24,24,27), ForeColor = Color.White, FormBorderStyle = FormBorderStyle.FixedDialog };
            var box = new TextBox { Dock = DockStyle.Top, Font = new Font("Segoe UI", 14), PlaceholderText = "Type a command…" };
            var list = new ListBox { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 11) };
            var commands = new[] { "Dashboard", "Widget Gallery", "DeskZones", "Wallpaper Studio", "System Monitor", "Profiles", "Performance", "Automation", "Enable Wallpaper", "Disable Wallpaper", "Work Profile", "Gaming Profile", "Focus Profile" };
            list.Items.AddRange(commands);
            void Execute()
            {
                if (list.SelectedItem is not string c) return;
                switch (c) {
                    case "Dashboard": ShowDashboard(); break; case "Widget Gallery": ShowWidgets(); break; case "DeskZones": ShowDeskZones(); break;
                    case "Wallpaper Studio": ShowWallpaper(); break; case "System Monitor": ShowMonitor(); break; case "Profiles": ShowProfiles(); break;
                    case "Performance": ShowPerformance(); break; case "Automation": ShowAutomation(); break; case "Enable Wallpaper": WallpaperHostEngine.Instance.Enable(); break;
                    case "Disable Wallpaper": WallpaperHostEngine.Instance.Disable(); break; case "Work Profile": LoadProfileFromQuickButton("Work"); break;
                    case "Gaming Profile": LoadProfileFromQuickButton("Gaming"); break; case "Focus Profile": LoadProfileFromQuickButton("Focus"); break;
                }
                dialog.Close();
            }
            box.TextChanged += (_, _) => { list.Items.Clear(); list.Items.AddRange(commands.Where(c => c.Contains(box.Text, StringComparison.OrdinalIgnoreCase)).ToArray()); };
            list.DoubleClick += (_, _) => Execute(); box.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) Execute(); };
            dialog.Controls.Add(list); dialog.Controls.Add(box); box.Focus(); dialog.ShowDialog(this);
        }

        private void ShowProfiles()
        {
            var panel = CreatePagePanel(); AddHeading(panel, "Workspace Profiles");
            AddText(panel, "Αποθήκευσε ολόκληρο το desktop setup και φόρτωσέ το με ένα click.");
            var list = new ListBox { Width = 440, Height = 180, Font = new Font("Segoe UI", 10) };
            void Refresh() { list.Items.Clear(); foreach (var p in WorkspaceProfileService.ListProfiles()) list.Items.Add(p); }
            Refresh(); panel.Controls.Add(list);
            var name = new TextBox { Width = 240, Text = "Work" }; panel.Controls.Add(name);
            AddButton(panel, "Save current as profile", (_, _) => { if (!string.IsNullOrWhiteSpace(name.Text)) { WorkspaceProfileService.Save(name.Text.Trim()); Refresh(); } });
            AddButton(panel, "Load selected", (_, _) => { if (list.SelectedItem is string p && WorkspaceProfileService.Load(p)) { ShowDashboard(); } });
            AddButton(panel, "Create / update Work, Gaming, Focus", (_, _) => { foreach (var p in new[] { "Work", "Gaming", "Focus" }) WorkspaceProfileService.Save(p); Refresh(); });
            AddButton(panel, "Delete selected profile", (_, _) => { if (list.SelectedItem is string p && !p.Equals("Last Session", StringComparison.OrdinalIgnoreCase)) { WorkspaceProfileService.Delete(p); Refresh(); } });
            SetPage("Profiles", panel);
        }

        private void ShowPerformance()
        {
            var panel = CreatePagePanel(); AddHeading(panel, "Performance Center");
            AddText(panel, "Παρακολούθηση του ίδιου του MotionDesk και των βασικών system resources.");
            var card = AddCard(panel, "Live metrics", "Starting…");
            var timer = new System.Windows.Forms.Timer { Interval = 2000 };
            timer.Tick += (_, _) => { var m = AdvancedSystemMonitorService.Instance.GetSnapshot(); card.Text = $"CPU {m.CpuPercent:0.0}%  •  RAM {m.AvailableMemoryMb:0}/{m.TotalMemoryMb:0} MB  •  ↓ {m.NetworkDownKbps:0.0} KB/s  ↑ {m.NetworkUpKbps:0.0} KB/s  •  {m.ProcessCount} processes"; };
            timer.Start(); panel.Disposed += (_, _) => timer.Dispose(); SetPage("Performance", panel);
        }

        private void ShowAutomation()
        {
            var panel = CreatePagePanel(); AddHeading(panel, "Automation");
            AddText(panel, "Κανόνες τύπου: όταν ξεκινάει μια εφαρμογή → φόρτωσε workspace profile.");
            foreach (var rule in AutomationService.Instance.Rules)
            {
                var row = new CheckBox { Text = $"{rule.Name}  ·  {rule.TriggerProcess}  →  {rule.Profile}", Checked = rule.Enabled, AutoSize = true, ForeColor = Color.White };
                row.CheckedChanged += (_, _) => { rule.Enabled = row.Checked; AutomationService.Instance.Save(); };
                panel.Controls.Add(row);
            }
            AddButton(panel, "Add Gaming rule", (_, _) => { AutomationService.Instance.Rules.Add(new AutomationRule { Name = "Gaming Mode", TriggerProcess = "steam.exe", Profile = "Gaming" }); AutomationService.Instance.Save(); ShowAutomation(); });
            SetPage("Automation", panel);
        }

        private bool _gamingModeActive;
        private void ToggleGamingMode() => LoadProfileFromQuickButton(_gamingModeActive ? "Work" : "Gaming", true);
        private void LoadProfileFromQuickButton(string profile, bool toggle = false)
        {
            if (WorkspaceProfileService.Load(profile)) { if (toggle) _gamingModeActive = !_gamingModeActive; _statusLabel.Text = $"Profile loaded: {profile}"; }
            else _statusLabel.Text = $"Profile not found: {profile}";
        }

        private void CreateZoneLayout(int columns, int rows)
        {
            DeskZoneHostEngine.Instance.CloseAll();
            var area = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1280, 720);
            int margin = 30, gap = 14;
            int w = (area.Width - margin * 2 - gap * (columns - 1)) / columns;
            int h = (area.Height - margin * 2 - gap * (rows - 1)) / rows;
            for (int y = 0; y < rows; y++) for (int x = 0; x < columns; x++)
                DeskZoneHostEngine.Instance.SpawnZone($"zone-{x}-{y}-{DateTime.Now.Ticks}", $"Zone {x + 1},{y + 1}", area.Left + margin + x * (w + gap), area.Top + margin + y * (h + gap), w, h);
            _statusLabel.Text = $"Created {columns * rows} DeskZones";
        }

        private void ShowAbout()
        {
            var panel = CreatePagePanel();
            AddHeading(panel, "About MotionDesk Studio");
            AddText(panel, ".NET 8 Windows desktop workspace manager.");
            AddText(panel, "This build uses a real application shell while desktop overlays remain independently managed.");
            AddSection(panel, "Included capabilities");
            AddText(panel, "Native widgets • snap-to-grid • multi-monitor recovery • DeskZone layouts • live wallpaper • audio visualizer • profiles • automation • command palette • tray integration • global hotkeys • battery-aware performance modes.");
            AddText(panel, $"Runtime: .NET 8 / WinForms / win-x64   •   WebView2: lazy-loaded   •   Active widgets: {WidgetHostEngine.Instance.GetActiveWidgets().Count}");
            SetPage("About", panel);
        }

        private FlowLayoutPanel CreatePagePanel() => new()
        {
            AutoScroll = true,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            Padding = new Padding(4),
            BackColor = Color.FromArgb(18, 18, 20)
        };

        private static void AddHeading(Control parent, string text)
        {
            parent.Controls.Add(new Label
            {
                AutoSize = true,
                Width = 760,
                Text = text,
                Font = new Font("Segoe UI", 18f, FontStyle.Bold),
                ForeColor = Color.White,
                Margin = new Padding(0, 0, 0, 4)
            });
        }

        private static void AddText(Control parent, string text)
        {
            parent.Controls.Add(new Label
            {
                AutoSize = true,
                MaximumSize = new Size(780, 0),
                Text = text,
                Font = new Font("Segoe UI", 10f),
                ForeColor = Color.Silver,
                Margin = new Padding(0, 0, 0, 12)
            });
        }

        private static void AddSection(Control parent, string text)
        {
            parent.Controls.Add(new Label
            {
                AutoSize = true,
                Text = text,
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.Gainsboro,
                Margin = new Padding(0, 10, 0, 4)
            });
        }

        private static Label AddCard(Control parent, string title, string value)
        {
            var card = new Panel
            {
                Width = 760,
                Height = 78,
                BackColor = Color.FromArgb(35, 35, 39),
                Padding = new Padding(14),
                Margin = new Padding(0, 0, 0, 8)
            };
            card.Controls.Add(new Label
            {
                Dock = DockStyle.Top,
                Height = 22,
                Text = title,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.Silver
            });
            var valueLabel = new Label
            {
                Dock = DockStyle.Fill,
                Text = value,
                Font = new Font("Segoe UI", 12f),
                ForeColor = Color.White
            };
            card.Controls.Add(valueLabel);
            parent.Controls.Add(card);
            return valueLabel;
        }

        private static void AddButton(Control parent, string text, EventHandler action)
        {
            var button = new Button
            {
                Text = text,
                Width = 300,
                Height = 40,
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.White,
                BackColor = Color.FromArgb(45, 45, 50),
                Margin = new Padding(0, 3, 0, 3),
                TabStop = false
            };
            button.FlatAppearance.BorderSize = 0;
            button.Click += (sender, e) => action(sender, e);
            parent.Controls.Add(button);
        }

        private static void SaveAppSettings()
        {
            var a = AppSettings.Load();
            a.GridSnap = WidgetSnapEngine.EnableGridSnap;
            a.SnapThreshold = WidgetSnapEngine.SnapThreshold;
            a.GridSize = WidgetSnapEngine.GridSize;
            a.Save();
        }

        private static void ChooseWallpaperVideo()
        {
            using var dialog = new OpenFileDialog
            {
                Filter = "Video (*.mp4;*.webm;*.mov;*.mkv)|*.mp4;*.webm;*.mov;*.mkv|All files (*.*)|*.*",
                Title = "Choose Wallpaper Video"
            };

            if (dialog.ShowDialog() == DialogResult.OK)
                WallpaperHostEngine.Instance.SetVideo(dialog.FileName);
        }

        private void UpdateStatus()
        {
            var m = SystemMonitorService.Instance.GetSnapshot();
            _statusLabel.Text = $"CPU {m.CpuPercent:0.0}%  •  RAM {m.AvailableMemoryMb:0} MB free";
        }

        private sealed class SettingsView : Panel
        {
            private readonly CheckBox _gridSnap;
            private readonly NumericUpDown _threshold;
            private readonly CheckBox _startup;
            private readonly CheckBox _sysmon;
            private readonly ComboBox _wallpaperMode;
            private readonly Label _videoPath;

            public SettingsView()
            {
                AutoScroll = true;
                var stack = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Padding = new Padding(4) };
                Controls.Add(stack);
                stack.Controls.Add(new Label { Text = "Application settings", Font = new Font("Segoe UI", 16, FontStyle.Bold), AutoSize = true, Margin = new Padding(0, 0, 0, 14) });

                _gridSnap = new CheckBox { Text = "Enable Grid Snap", AutoSize = true, Checked = AppSettings.Load().GridSnap };
                _gridSnap.CheckedChanged += (_, _) => { WidgetSnapEngine.EnableGridSnap = _gridSnap.Checked; SaveAppSettings(); };
                stack.Controls.Add(_gridSnap);

                var snap = new FlowLayoutPanel { AutoSize = true, WrapContents = false };
                snap.Controls.Add(new Label { Text = "Snap threshold:", AutoSize = true, Padding = new Padding(0, 6, 8, 0) });
                _threshold = new NumericUpDown { Minimum = 5, Maximum = 50, Value = AppSettings.Load().SnapThreshold, Width = 80 };
                _threshold.ValueChanged += (_, _) => { WidgetSnapEngine.SnapThreshold = (int)_threshold.Value; SaveAppSettings(); };
                snap.Controls.Add(_threshold);
                snap.Controls.Add(new Label { Text = "px", AutoSize = true, Padding = new Padding(8, 6, 0, 0) });
                stack.Controls.Add(snap);

                var grid = new FlowLayoutPanel { AutoSize = true, WrapContents = false };
                grid.Controls.Add(new Label { Text = "Grid size:", AutoSize = true, Padding = new Padding(0, 6, 8, 0) });
                var gridSize = new NumericUpDown { Minimum = 5, Maximum = 100, Value = Math.Clamp(AppSettings.Load().GridSize, 5, 100), Width = 80 };
                gridSize.ValueChanged += (_, _) => { WidgetSnapEngine.GridSize = (int)gridSize.Value; SaveAppSettings(); };
                grid.Controls.Add(gridSize);
                grid.Controls.Add(new Label { Text = "px", AutoSize = true, Padding = new Padding(8, 6, 0, 0) });
                stack.Controls.Add(grid);

                var autoPerf = new CheckBox { Text = "Automatically use Battery/Low Power wallpaper mode", AutoSize = true, Checked = AppSettings.Load().AutoPerformanceMode, Margin = new Padding(0, 10, 0, 0) };
                autoPerf.CheckedChanged += (_, _) => { var a = AppSettings.Load(); a.AutoPerformanceMode = autoPerf.Checked; a.Save(); };
                stack.Controls.Add(autoPerf);

                var wallpaperStartup = new CheckBox { Text = "Start live wallpaper with MotionDesk", AutoSize = true, Checked = AppSettings.Load().StartWallpaperWithWindows, Margin = new Padding(0, 8, 0, 0) };
                wallpaperStartup.CheckedChanged += (_, _) => { var a = AppSettings.Load(); a.StartWallpaperWithWindows = wallpaperStartup.Checked; a.Save(); };
                stack.Controls.Add(wallpaperStartup);

                _sysmon = new CheckBox { Text = "Show System Monitor widget", AutoSize = true, Checked = AppSettings.Load().ShowSystemMonitor || WidgetHostEngine.Instance.GetActiveWidgets().Any(w => w.WidgetId == "sysmon"), Margin = new Padding(0, 10, 0, 0) };
                _sysmon.CheckedChanged += (_, _) =>
                {
                    if (_sysmon.Checked) WidgetHostEngine.Instance.SpawnWidget("sysmon", 100, 100, 300, 200);
                    else WidgetHostEngine.Instance.GetActiveWidgets().FirstOrDefault(w => w.WidgetId == "sysmon")?.Close();
                    var a = AppSettings.Load(); a.ShowSystemMonitor = _sysmon.Checked; a.Save();
                };
                stack.Controls.Add(_sysmon);

                _startup = new CheckBox { Text = "Start MotionDesk with Windows", AutoSize = true, Checked = StartupManager.IsStartupEnabled(), Margin = new Padding(0, 8, 0, 0) };
                _startup.CheckedChanged += (_, _) => StartupManager.SetStartup(_startup.Checked);
                stack.Controls.Add(_startup);

                var restore = new CheckBox { Text = "Restore Last Session on launch", AutoSize = true, Checked = AppSettings.Load().RestoreLastSession, Margin = new Padding(0, 8, 0, 0) };
                restore.CheckedChanged += (_, _) => { var a = AppSettings.Load(); a.RestoreLastSession = restore.Checked; a.Save(); };
                stack.Controls.Add(restore);

                var animations = new CheckBox { Text = "Enable animated / visual effects", AutoSize = true, Checked = AppSettings.Load().EnableAnimations, Margin = new Padding(0, 8, 0, 0) };
                animations.CheckedChanged += (_, _) => { var a = AppSettings.Load(); a.EnableAnimations = animations.Checked; a.Save(); };
                stack.Controls.Add(animations);

                var group = new GroupBox { Text = "Wallpaper", Width = 560, Height = 140, Margin = new Padding(0, 18, 0, 0), Padding = new Padding(12) };
                _videoPath = new Label { AutoSize = true, MaximumSize = new Size(520, 0), ForeColor = Color.Silver };
                group.Controls.Add(_videoPath);
                var choose = new Button { Text = "Choose video", AutoSize = true, Location = new Point(12, 55), FlatStyle = FlatStyle.Flat };
                choose.Click += ChooseVideo;
                group.Controls.Add(choose);
                var clear = new Button { Text = "Clear video", AutoSize = true, Location = new Point(120, 55), FlatStyle = FlatStyle.Flat };
                clear.Click += (_, _) => { WallpaperHostEngine.Instance.ClearVideo(); RefreshVideo(); };
                group.Controls.Add(clear);
                group.Controls.Add(new Label { Text = "Performance:", AutoSize = true, Location = new Point(230, 62) });
                _wallpaperMode = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 100, Location = new Point(315, 58) };
                _wallpaperMode.Items.AddRange(new object[] { "High", "Balanced", "Low Power", "Battery" });
                _wallpaperMode.SelectedItem = WallpaperSettings.Load().PerformanceMode;
                if (_wallpaperMode.SelectedIndex < 0) _wallpaperMode.SelectedIndex = 1;
                _wallpaperMode.SelectedIndexChanged += (_, _) => WallpaperHostEngine.Instance.SetPerformanceMode((string)_wallpaperMode.SelectedItem!);
                group.Controls.Add(_wallpaperMode);
                stack.Controls.Add(group);
                RefreshVideo();
            }

            private void ChooseVideo(object? sender, EventArgs e)
            {
                using var d = new OpenFileDialog { Filter = "Video (*.mp4;*.webm;*.mov;*.mkv)|*.mp4;*.webm;*.mov;*.mkv|All files (*.*)|*.*" };
                if (d.ShowDialog(FindForm()) == DialogResult.OK) { WallpaperHostEngine.Instance.SetVideo(d.FileName); RefreshVideo(); }
            }

            private void RefreshVideo()
            {
                var path = WallpaperSettings.Load().VideoPath;
                _videoPath.Text = string.IsNullOrWhiteSpace(path) || !File.Exists(path) ? "No video selected - Aurora background is used." : $"Active video: {Path.GetFileName(path)}";
            }
        }

        private static Icon LoadApplicationIcon()
        {
            var path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "MotionDesk.ico");
            return File.Exists(path) ? new Icon(path) : SystemIcons.Application;
        }
    }
}
