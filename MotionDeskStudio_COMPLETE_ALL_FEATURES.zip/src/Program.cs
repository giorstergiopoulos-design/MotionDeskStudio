using System;
using System.Windows.Forms;
using MotionDesk.Widgets;

namespace MotionDesk
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) => ReportError(e.Exception);
            AppDomain.CurrentDomain.UnhandledException += (s, e) => ReportError(e.ExceptionObject as Exception);

            ApplicationConfiguration.Initialize();
            Application.Run(new TrayApplicationContext());
        }

        private static void ReportError(Exception? ex)
        {
            if (ex == null) return;
            MessageBox.Show($"Παρουσιάστηκε σφάλμα:\n\n{ex.Message}", "MotionDesk Studio",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
