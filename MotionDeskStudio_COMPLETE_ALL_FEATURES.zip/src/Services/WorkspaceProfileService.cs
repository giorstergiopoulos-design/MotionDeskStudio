using System.Text.Json;
using MotionDesk.Widgets;

namespace MotionDesk.Services;

public sealed class WorkspaceProfile
{
    public string Name { get; set; } = "Default";
    public AppSettings AppSettings { get; set; } = new();
    public WallpaperSettingsSnapshot Wallpaper { get; set; } = new();
    public List<ZoneSnapshot> Zones { get; set; } = new();
    public List<WidgetSnapshot> Widgets { get; set; } = new();
}

public sealed class WallpaperSettingsSnapshot
{
    public string VideoPath { get; set; } = string.Empty;
    public string PerformanceMode { get; set; } = "Balanced";
    public bool Enabled { get; set; }
}

public sealed class ZoneSnapshot
{
    public string FileName { get; set; } = string.Empty;
    public string Json { get; set; } = string.Empty;
    public string ZoneId { get; set; } = string.Empty;
    public string Title { get; set; } = "DeskZone";
    public int X { get; set; }
    public int Y { get; set; }
    public int Width { get; set; } = 360;
    public int Height { get; set; } = 240;
}

public static class WorkspaceProfileService
{
    private static string Root => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MotionDeskStudio", "profiles");

    public static IReadOnlyList<string> ListProfiles()
    {
        Directory.CreateDirectory(Root);
        return Directory.GetFiles(Root, "*.json")
            .Select(Path.GetFileNameWithoutExtension)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .OrderBy(x => x)
            .ToArray()!;
    }

    public static void Save(string name)
    {
        name = Sanitize(name);
        Directory.CreateDirectory(Root);
        var wallpaper = WallpaperSettings.Load();
        var profile = new WorkspaceProfile
        {
            Name = name,
            AppSettings = AppSettings.Load(),
            Wallpaper = new WallpaperSettingsSnapshot
            {
                VideoPath = wallpaper.VideoPath,
                PerformanceMode = wallpaper.PerformanceMode,
                Enabled = WallpaperHostEngine.Instance.IsEnabled
            },
            Widgets = WidgetHostEngine.Instance.GetSnapshots().ToList()
        };

        var zoneDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MotionDeskStudio", "deskzones");
        if (Directory.Exists(zoneDir))
        {
            foreach (var file in Directory.GetFiles(zoneDir, "*_config.json"))
            {
                try
                {
                    var json = File.ReadAllText(file);
                    var state = JsonSerializer.Deserialize<DeskZoneState>(json);
                    profile.Zones.Add(new ZoneSnapshot
                    {
                        FileName = Path.GetFileName(file),
                        Json = json,
                        ZoneId = Path.GetFileNameWithoutExtension(file).Replace("_config", "", StringComparison.OrdinalIgnoreCase),
                        Title = state?.Title ?? "DeskZone",
                        X = state?.X ?? 100,
                        Y = state?.Y ?? 100,
                        Width = state?.Width > 0 ? state.Width : 360,
                        Height = state?.Height > 0 ? state.Height : 240
                    });
                }
                catch { }
            }
        }

        File.WriteAllText(Path.Combine(Root, name + ".json"), JsonSerializer.Serialize(profile, new JsonSerializerOptions { WriteIndented = true }));
    }

    public static bool Load(string name)
    {
        var path = Path.Combine(Root, Sanitize(name) + ".json");
        if (!File.Exists(path)) return false;
        WorkspaceProfile? profile;
        try { profile = JsonSerializer.Deserialize<WorkspaceProfile>(File.ReadAllText(path)); }
        catch (JsonException) { return false; }
        if (profile == null) return false;

        profile.AppSettings.Save();
        var wallpaper = WallpaperSettings.Load();
        wallpaper.VideoPath = profile.Wallpaper.VideoPath ?? string.Empty;
        wallpaper.PerformanceMode = profile.Wallpaper.PerformanceMode ?? "Balanced";
        wallpaper.Save();

        WidgetSnapEngine.EnableGridSnap = profile.AppSettings.GridSnap;
        WidgetSnapEngine.SnapThreshold = Math.Clamp(profile.AppSettings.SnapThreshold, 5, 50);
        WidgetSnapEngine.GridSize = Math.Clamp(profile.AppSettings.GridSize, 5, 100);

        WidgetHostEngine.Instance.RestoreSnapshots(profile.Widgets ?? new List<WidgetSnapshot>());
        DeskZoneHostEngine.Instance.CloseAll();

        var zoneDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MotionDeskStudio", "deskzones");
        Directory.CreateDirectory(zoneDir);
        foreach (var existing in Directory.GetFiles(zoneDir, "*_config.json"))
        {
            try { File.Delete(existing); } catch { }
        }

        foreach (var zone in profile.Zones ?? new List<ZoneSnapshot>())
        {
            if (!string.IsNullOrWhiteSpace(zone.Json))
            {
                try { File.WriteAllText(Path.Combine(zoneDir, Path.GetFileName(zone.FileName)), zone.Json); } catch { }
            }
            var id = string.IsNullOrWhiteSpace(zone.ZoneId) ? Path.GetFileNameWithoutExtension(zone.FileName).Replace("_config", "") : zone.ZoneId;
            if (!string.IsNullOrWhiteSpace(id))
                DeskZoneHostEngine.Instance.SpawnZone(id, zone.Title, zone.X, zone.Y, zone.Width, zone.Height);
        }

        WallpaperHostEngine.Instance.SetPerformanceMode(wallpaper.PerformanceMode);
        if (profile.Wallpaper.Enabled) WallpaperHostEngine.Instance.Enable();
        else WallpaperHostEngine.Instance.Disable();
        return true;
    }

    public static void Delete(string name)
    {
        var path = Path.Combine(Root, Sanitize(name) + ".json");
        try { if (File.Exists(path)) File.Delete(path); } catch { }
    }

    private static string Sanitize(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var clean = new string((value ?? "Default").Where(c => !invalid.Contains(c)).ToArray()).Trim();
        return string.IsNullOrWhiteSpace(clean) ? "Default" : clean;
    }
}
