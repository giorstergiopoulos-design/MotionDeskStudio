using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace MotionDesk.Services
{
    public class WeatherService
    {
        private static readonly HttpClient _httpClient = new();

        public static async Task<string> GetWeatherJsonAsync(double latitude = 37.9838, double longitude = 23.7275)
        {
            try
            {
                string url = $"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current_weather=true";
                return await _httpClient.GetStringAsync(url);
            }
            catch (Exception ex)
            {
                return JsonSerializer.Serialize(new { error = ex.Message });
            }
        }
    }
}
