using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Win32;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
using MotionDesk.Services;

namespace MotionDesk.Widgets
{
    [ClassInterface(ClassInterfaceType.AutoDual)]
    [ComVisible(true)]
    public sealed class WallpaperBridge : IDisposable
    {
        private AudioPeakService? _audio;

        public string GetVideoPathUri()
        {
            string path = WallpaperSettings.Load().VideoPath;
            return string.IsNullOrEmpty(path) || !File.Exists(path) ? string.Empty : new Uri(path).AbsoluteUri;
        }

        public float GetAudioPeak()
        {
            _audio ??= new AudioPeakService();
            return _audio.GetPeak();
        }

        public string GetPerformanceMode() => WallpaperSettings.Load().PerformanceMode;

        public void Dispose() => _audio?.Dispose();
    }

    public sealed class WallpaperSettings
    {
        public string VideoPath { get; set; } = string.Empty;
        public string PerformanceMode { get; set; } = "Balanced";

        private static string ConfigPath => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "MotionDeskStudio", "wallpaper.json");

        public static WallpaperSettings Load()
        {
            try
            {
                if (File.Exists(ConfigPath))
                    return JsonSerializer.Deserialize<WallpaperSettings>(File.ReadAllText(ConfigPath)) ?? new WallpaperSettings();
            }
            catch (JsonException) { }
            return new WallpaperSettings { PerformanceMode = AppSettings.Load().WallpaperPerformanceMode };
        }

        public void Save()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(ConfigPath)!);
            File.WriteAllText(ConfigPath, JsonSerializer.Serialize(this));
        }
    }

    public sealed class WallpaperWindow : Form
    {
        private WebView2? _webView;
        private WallpaperBridge? _bridge;
        private bool _initializing;

        public WallpaperWindow()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            Bounds = SystemInformation.VirtualScreen;
            BackColor = Color.Black;
            SystemEvents.DisplaySettingsChanged += OnDisplaySettingsChanged;
        }

        protected override CreateParams CreateParams
        {
            get { var cp = base.CreateParams; cp.ExStyle |= WS_EX_TOOLWINDOW; return cp; }
        }

        private void OnDisplaySettingsChanged(object? sender, EventArgs e)
        {
            if (!IsDisposed) BeginInvoke(new Action(() => Bounds = SystemInformation.VirtualScreen));
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            WallpaperInterop.AttachToDesktop(Handle);
            SendToBack();
            if (!_initializing) _ = InitializeWebViewAsync();
        }

        public void SetVideoPath(string path)
        {
            var settings = WallpaperSettings.Load();
            settings.VideoPath = path ?? string.Empty;
            settings.Save();
            _ = RefreshWebViewAsync();
        }

        public void SetPerformanceMode(string mode)
        {
            var settings = WallpaperSettings.Load();
            settings.PerformanceMode = mode;
            settings.Save();
            var app = AppSettings.Load();
            app.WallpaperPerformanceMode = mode;
            app.Save();
            _ = RefreshWebViewAsync();
        }

        private async Task InitializeWebViewAsync()
        {
            if (_initializing || IsDisposed) return;
            _initializing = true;
            try
            {
                _webView = new WebView2 { Dock = DockStyle.Fill, DefaultBackgroundColor = Color.Black };
                Controls.Add(_webView);
                await _webView.EnsureCoreWebView2Async(await WebView2Support.CreateEnvironmentAsync());
                if (IsDisposed || _webView.CoreWebView2 == null) return;
                _bridge = new WallpaperBridge();
                _webView.CoreWebView2.AddHostObjectToScript("wallpaper", _bridge);
                string htmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "widgets", "wallpaper", "index.html");
                if (File.Exists(htmlPath)) _webView.CoreWebView2.Navigate(htmlPath);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Wallpaper WebView2 initialization failed: {ex}");
            }
            finally { _initializing = false; }
        }

        private async Task RefreshWebViewAsync()
        {
            if (_webView?.CoreWebView2 == null) return;
            try { await _webView.CoreWebView2.ExecuteScriptAsync("window.motionDeskRefresh?.();"); }
            catch (Exception ex) { System.Diagnostics.Debug.WriteLine(ex); }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _bridge?.Dispose();
                _bridge = null;
                _webView?.Dispose();
                _webView = null;
                SystemEvents.DisplaySettingsChanged -= OnDisplaySettingsChanged;
            }
            base.Dispose(disposing);
        }

        private const int WS_EX_TOOLWINDOW = 0x00000080;
    }

    public sealed class WallpaperHostEngine
    {
        private static WallpaperHostEngine? _instance;
        public static WallpaperHostEngine Instance => _instance ??= new WallpaperHostEngine();

        private WallpaperWindow? _window;
        public bool IsEnabled => _window != null && !_window.IsDisposed && _window.Visible;

        public void EnsureStarted() => Enable();

        public void Enable()
        {
            var app = AppSettings.Load();
            if (app.AutoPerformanceMode)
            {
                var recommended = PerformanceModeManager.GetRecommendedMode();
                var settings = WallpaperSettings.Load();
                if (recommended != settings.PerformanceMode) { settings.PerformanceMode = recommended; settings.Save(); }
            }
            if (_window == null || _window.IsDisposed)
            {
                _window = new WallpaperWindow();
                _window.FormClosed += (_, _) => _window = null;
            }
            if (!_window.Visible) _window.Show();
            else _window.BringToFront();
        }

        public void Disable()
        {
            if (_window == null || _window.IsDisposed) return;
            _window.Hide();
        }

        public void SetVideo(string path)
        {
            Enable();
            _window!.SetVideoPath(path);
        }

        public void ClearVideo()
        {
            var settings = WallpaperSettings.Load();
            settings.VideoPath = string.Empty;
            settings.Save();
            _window?.SetVideoPath(string.Empty);
        }

        public void SetPerformanceMode(string mode)
        {
            if (string.IsNullOrWhiteSpace(mode)) mode = "Balanced";
            if (_window == null || _window.IsDisposed)
            {
                var settings = WallpaperSettings.Load();
                settings.PerformanceMode = mode;
                settings.Save();
                var app = AppSettings.Load();
                app.WallpaperPerformanceMode = mode;
                app.Save();
                return;
            }
            _window.SetPerformanceMode(mode);
        }
    }
}
