using System.Collections.Generic;
using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows.Forms;

namespace MotionDesk.Widgets
{
    // Ημιδιαφανής container οργάνωσης της επιφάνειας εργασίας (πρώην "Fences", μετονομάστηκε
    // σε DeskZones για να αποφευχθεί σύγκρουση με το κατοχυρωμένο σήμα Stardock Fences).
    public class DeskZoneWindow : Form
    {
        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HTCAPTION = 0x2;
        private const int TitleBarHeight = 28;

        private readonly string _zoneId;
        private readonly int _expandedHeight;
        private const int CollapsedHeight = TitleBarHeight;
        private bool _isRolledUp;
        private string _title;

        public string ZoneId => _zoneId;
        public string ZoneTitle => _title;
        private readonly System.Windows.Forms.Timer _saveTimer;

        public DeskZoneWindow(string zoneId, string title, int x, int y, int width, int height)
        {
            _zoneId = zoneId;
            _title = title;
            _expandedHeight = height;

            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            BackColor = Color.FromArgb(24, 24, 24);
            Size = new Size(width, height);

            LoadZoneState(x, y);

            _saveTimer = new System.Windows.Forms.Timer { Interval = 350 };
            _saveTimer.Tick += (_, _) =>
            {
                _saveTimer.Stop();
                SaveZoneState();
            };
            FormClosed += (_, _) =>
            {
                _saveTimer.Stop();
                _saveTimer.Dispose();
                SaveZoneState();
            };

            MouseLeave += (s, e) => ToggleRollUp(true);
            MouseEnter += (s, e) => ToggleRollUp(false);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            ApplyGlassBlur();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using var titleBrush = new SolidBrush(Color.FromArgb(255, 255, 255));
            using var font = new Font("Segoe UI", 9f, FontStyle.Bold);
            e.Graphics.DrawString(_title, font, titleBrush, new PointF(10, 6));

            using var separator = new Pen(Color.FromArgb(60, 255, 255, 255));
            e.Graphics.DrawLine(separator, 0, TitleBarHeight, Width, TitleBarHeight);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Y <= TitleBarHeight && e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
            else if (e.Y <= TitleBarHeight && e.Button == MouseButtons.Right)
            {
                using var menu = new ContextMenuStrip();
                menu.Items.Add("Rename zone…", null, (_, _) => RenameZone());
                menu.Items.Add("Close zone", null, (_, _) => Close());
                menu.Show(this, e.Location);
            }
        }

        protected override void OnMove(EventArgs e)
        {
            base.OnMove(e);
            // Do not write JSON for every WM_MOVE while the user is dragging.
            _saveTimer.Stop();
            _saveTimer.Start();
        }

        private void RenameZone()
        {
            using var dialog = new Form { Text = "Rename DeskZone", StartPosition = FormStartPosition.CenterParent, Size = new Size(420, 150), FormBorderStyle = FormBorderStyle.FixedDialog, MinimizeBox = false, MaximizeBox = false };
            var box = new TextBox { Text = _title, Dock = DockStyle.Top, Margin = new Padding(12) };
            var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Dock = DockStyle.Bottom, Height = 34 };
            dialog.Controls.Add(box);
            dialog.Controls.Add(ok);
            dialog.AcceptButton = ok;
            if (dialog.ShowDialog(this) == DialogResult.OK && !string.IsNullOrWhiteSpace(box.Text))
            {
                _title = box.Text.Trim();
                Invalidate();
                SaveZoneState();
            }
        }

        private void ToggleRollUp(bool collapse)
        {
            if (_isRolledUp == collapse) return;
            _isRolledUp = collapse;
            Height = _isRolledUp ? CollapsedHeight : _expandedHeight;
        }

        private void ApplyGlassBlur()
        {
            var accent = new ACCENT_POLICY { AccentState = 3 /* ENABLE_BLURBEHIND */, GradientColor = unchecked((int)0x99202020) };
            int size = Marshal.SizeOf(accent);
            IntPtr accentPtr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(accent, accentPtr, false);

            var data = new WINDOWCOMPOSITIONATTRIBDATA
            {
                Attribute = 19 /* WCA_ACCENT_POLICY */,
                SizeOfData = size,
                Data = accentPtr
            };

            SetWindowCompositionAttribute(Handle, ref data);
            Marshal.FreeHGlobal(accentPtr);
        }

        private void SaveZoneState()
        {
            try
            {
                var path = GetConfigFilePath();
                Directory.CreateDirectory(Path.GetDirectoryName(path)!);
                var state = new DeskZoneState { X = Location.X, Y = Location.Y, Width = Width, Height = _expandedHeight, Title = _title };
                File.WriteAllText(path, JsonSerializer.Serialize(state));
            }
            catch (IOException) { }
        }

        private void LoadZoneState(int defaultX, int defaultY)
        {
            var path = GetConfigFilePath();
            if (File.Exists(path))
            {
                try
                {
                    var state = JsonSerializer.Deserialize<DeskZoneState>(File.ReadAllText(path));
                    if (state != null)
                    {
                        if (state.Width > 180 && state.Height > 120)
                            Size = new Size(Math.Clamp(state.Width, 220, 1600), Math.Clamp(state.Height, 140, 1000));
                        Location = ClampToAvailableScreen(new Point(state.X, state.Y));
                        _title = state.Title ?? _title;
                        return;
                    }
                }
                catch (JsonException) { }
            }

            Location = ClampToAvailableScreen(new Point(defaultX, defaultY));
        }

        private Point ClampToAvailableScreen(Point location)
        {
            var screen = Array.Find(Screen.AllScreens, s => s.WorkingArea.Contains(location)) ?? Screen.PrimaryScreen;
            if (screen == null) return location;
            var area = screen.WorkingArea;
            return new Point(Math.Clamp(location.X, area.Left, Math.Max(area.Left, area.Right - Width)), Math.Clamp(location.Y, area.Top, Math.Max(area.Top, area.Bottom - Height)));
        }

        private string GetConfigFilePath() =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "MotionDeskStudio", "deskzones", $"{_zoneId}_config.json");

        [StructLayout(LayoutKind.Sequential)]
        private struct ACCENT_POLICY
        {
            public int AccentState;
            public int AccentFlags;
            public int GradientColor;
            public int AnimationId;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct WINDOWCOMPOSITIONATTRIBDATA
        {
            public int Attribute;
            public IntPtr Data;
            public int SizeOfData;
        }

        [DllImport("user32.dll")] private static extern bool ReleaseCapture();
        [DllImport("user32.dll")] private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")] private static extern int SetWindowCompositionAttribute(IntPtr hwnd, ref WINDOWCOMPOSITIONATTRIBDATA data);
    }

    public class DeskZoneState
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public string? Title { get; set; }
    }

    public class DeskZoneHostEngine
    {
        private static DeskZoneHostEngine? _instance;
        public static DeskZoneHostEngine Instance => _instance ??= new DeskZoneHostEngine();

        private readonly System.Collections.Generic.List<DeskZoneWindow> _activeZones = new();

        public IReadOnlyCollection<DeskZoneWindow> GetActiveZones() => _activeZones;

        public void CloseAll()
        {
            foreach (var zone in new System.Collections.Generic.List<DeskZoneWindow>(_activeZones))
                if (!zone.IsDisposed) zone.Close();
            _activeZones.Clear();
        }

        public DeskZoneWindow SpawnZone(string zoneId, string title, int x, int y, int width, int height)
        {
            var existing = _activeZones.Find(z => z.Tag as string == zoneId);
            if (existing != null && !existing.IsDisposed) { existing.BringToFront(); return existing; }
            var zone = new DeskZoneWindow(zoneId, title, x, y, width, height) { Tag = zoneId };
            _activeZones.Add(zone);
            zone.FormClosed += (s, e) => _activeZones.Remove(zone);
            zone.Show();
            return zone;
        }
    }
}
