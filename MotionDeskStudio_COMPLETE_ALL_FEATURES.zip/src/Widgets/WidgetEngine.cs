using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
using MotionDesk.Services;

namespace MotionDesk.Widgets
{
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [ClassInterface(ClassInterfaceType.AutoDual)]
    [ComVisible(true)]
    public class WidgetBridge
    {
        private readonly WidgetWindow _window;

        public WidgetBridge(WidgetWindow window)
        {
            _window = window;
        }

        public float GetCpuUsage() => (float)SystemMonitorService.Instance.GetSnapshot().CpuPercent;
        public float GetAvailableRam() => (float)SystemMonitorService.Instance.GetSnapshot().AvailableMemoryMb;

        public string GetSystemStatsJson()
        {
            var metrics = SystemMonitorService.Instance.GetSnapshot();
            return JsonSerializer.Serialize(new
            {
                cpu = metrics.CpuPercent,
                ramAvailableMb = metrics.AvailableMemoryMb,
                ramTotalMb = metrics.TotalMemoryMb,
                timestamp = metrics.Timestamp.ToString("HH:mm:ss")
            });
        }

        public async System.Threading.Tasks.Task<string> GetWeatherDataJson(double lat, double lon)
        {
            return await WeatherService.GetWeatherJsonAsync(lat, lon);
        }

        public void StartDrag()
        {
            if (!_window.IsLocked) _window.BeginNativeDrag();
        }

        public bool ToggleLock()
        {
            _window.IsLocked = !_window.IsLocked;
            _window.SaveWidgetState();
            return _window.IsLocked;
        }

        public bool GetIsLocked() => _window.IsLocked;
    }

    // Διαφανές top-most overlay που σχεδιάζει τις μπλε γραμμές ευθυγράμμισης κατά το drag.
    public class SnapOverlayWindow : Form
    {
        private static SnapOverlayWindow? _instance;
        public static SnapOverlayWindow Instance => _instance ??= new SnapOverlayWindow();

        private int? _vertLineX;
        private int? _horizLineY;

        private SnapOverlayWindow()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = Color.Magenta;
            TransparencyKey = Color.Magenta;
            Bounds = SystemInformation.VirtualScreen;

            int exStyle = GetWindowLong(Handle, GWL_EXSTYLE);
            SetWindowLong(Handle, GWL_EXSTYLE, exStyle | WS_EX_TRANSPARENT | WS_EX_LAYERED);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= WS_EX_TOOLWINDOW;
                return cp;
            }
        }

        public void ShowGuides(int? x, int? y)
        {
            _vertLineX = x;
            _horizLineY = y;

            if (x.HasValue || y.HasValue)
            {
                if (!Visible) Show();
                Invalidate();
            }
            else if (Visible)
            {
                Hide();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using var pen = new Pen(Color.FromArgb(220, 0, 210, 255), 2f) { DashStyle = System.Drawing.Drawing2D.DashStyle.Dash };

            if (_vertLineX.HasValue) e.Graphics.DrawLine(pen, _vertLineX.Value, 0, _vertLineX.Value, Height);
            if (_horizLineY.HasValue) e.Graphics.DrawLine(pen, 0, _horizLineY.Value, Width, _horizLineY.Value);
        }

        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_TRANSPARENT = 0x00000020;
        private const int WS_EX_LAYERED = 0x00080000;
        private const int WS_EX_TOOLWINDOW = 0x00000080;

        [DllImport("user32.dll")] private static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        [DllImport("user32.dll")] private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
    }

    // Υπολογίζει snap-to-edge (οθόνη) και snap-to-widget (γειτονικά widgets), με προαιρετικό grid snap.
    public static class WidgetSnapEngine
    {
        public static int SnapThreshold { get; set; } = 15;
        public static int GridSize { get; set; } = 20;
        public static bool EnableGridSnap { get; set; } = false;

        public static void ApplySnap(WidgetWindow currentWidget, ref RECT targetRect, IReadOnlyCollection<WidgetWindow> activeWidgets)
        {
            int width = targetRect.Right - targetRect.Left;
            int height = targetRect.Bottom - targetRect.Top;

            Rectangle workArea = Screen.FromHandle(currentWidget.Handle).WorkingArea;

            int? snapX = null;
            int? snapY = null;

            if (Math.Abs(targetRect.Left - workArea.Left) < SnapThreshold)
            {
                targetRect.Left = workArea.Left;
                targetRect.Right = targetRect.Left + width;
                snapX = workArea.Left;
            }
            else if (Math.Abs(targetRect.Right - workArea.Right) < SnapThreshold)
            {
                targetRect.Right = workArea.Right;
                targetRect.Left = targetRect.Right - width;
                snapX = workArea.Right;
            }

            if (Math.Abs(targetRect.Top - workArea.Top) < SnapThreshold)
            {
                targetRect.Top = workArea.Top;
                targetRect.Bottom = targetRect.Top + height;
                snapY = workArea.Top;
            }
            else if (Math.Abs(targetRect.Bottom - workArea.Bottom) < SnapThreshold)
            {
                targetRect.Bottom = workArea.Bottom;
                targetRect.Top = targetRect.Bottom - height;
                snapY = workArea.Bottom;
            }

            foreach (var other in activeWidgets)
            {
                if (other == currentWidget || !other.Visible) continue;
                Rectangle b = other.Bounds;

                if (Math.Abs(targetRect.Left - b.Right) < SnapThreshold) { targetRect.Left = b.Right; targetRect.Right = targetRect.Left + width; snapX = b.Right; }
                else if (Math.Abs(targetRect.Right - b.Left) < SnapThreshold) { targetRect.Right = b.Left; targetRect.Left = targetRect.Right - width; snapX = b.Left; }
                else if (Math.Abs(targetRect.Left - b.Left) < SnapThreshold) { targetRect.Left = b.Left; targetRect.Right = targetRect.Left + width; snapX = b.Left; }

                if (Math.Abs(targetRect.Top - b.Bottom) < SnapThreshold) { targetRect.Top = b.Bottom; targetRect.Bottom = targetRect.Top + height; snapY = b.Bottom; }
                else if (Math.Abs(targetRect.Bottom - b.Top) < SnapThreshold) { targetRect.Bottom = b.Top; targetRect.Top = targetRect.Bottom - height; snapY = b.Top; }
                else if (Math.Abs(targetRect.Top - b.Top) < SnapThreshold) { targetRect.Top = b.Top; targetRect.Bottom = targetRect.Top + height; snapY = b.Top; }
            }

            if (EnableGridSnap && GridSize > 0)
            {
                targetRect.Left = (int)(Math.Round((double)targetRect.Left / GridSize) * GridSize);
                targetRect.Right = targetRect.Left + width;
                targetRect.Top = (int)(Math.Round((double)targetRect.Top / GridSize) * GridSize);
                targetRect.Bottom = targetRect.Top + height;
            }

            targetRect.Left = Math.Clamp(targetRect.Left, workArea.Left, Math.Max(workArea.Left, workArea.Right - width));
            targetRect.Top = Math.Clamp(targetRect.Top, workArea.Top, Math.Max(workArea.Top, workArea.Bottom - height));
            targetRect.Right = targetRect.Left + width;
            targetRect.Bottom = targetRect.Top + height;
            SnapOverlayWindow.Instance.ShowGuides(snapX, snapY);
        }
    }

    public class WidgetWindow : Form
    {
        private const int WM_MOVING = 0x0216;
        private const int WM_EXITSIZEMOVE = 0x0232;

        private WebView2? _webView;
        private System.Windows.Forms.Timer? _nativeMonitorTimer;
        public string WidgetId { get; }
        public bool IsLocked { get; set; } = false;

        public WidgetWindow(string widgetId, int defaultX, int defaultY, int width, int height)
        {
            WidgetId = widgetId;
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.Manual;
            this.Size = new Size(width, height);
            this.ShowInTaskbar = false;
            this.BackColor = Color.Black;
            this.TransparencyKey = Color.Black;

            LoadWidgetState(defaultX, defaultY);
            if (string.Equals(widgetId, "sysmon", StringComparison.OrdinalIgnoreCase))
                InitializeNativeSystemMonitor();
            else if (string.Equals(widgetId, "clock", StringComparison.OrdinalIgnoreCase))
                InitializeNativeClock();
            else if (string.Equals(widgetId, "network", StringComparison.OrdinalIgnoreCase))
                InitializeNativeNetwork();
            else if (string.Equals(widgetId, "audio", StringComparison.OrdinalIgnoreCase))
                InitializeNativeAudio();
            else if (string.Equals(widgetId, "weather", StringComparison.OrdinalIgnoreCase))
                InitializeNativeWeather();
            else
                _ = InitializeWebViewAsync();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _nativeMonitorTimer?.Stop();
                _nativeMonitorTimer?.Dispose();
                _nativeMonitorTimer = null;
                _webView?.Dispose();
                _webView = null;
            }
            base.Dispose(disposing);
        }

        public void BeginNativeDrag()
        {
            ReleaseCapture();
            SendMessage(Handle, 0xA1, 0x2, 0);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_MOVING && !IsLocked)
            {
                RECT rect = Marshal.PtrToStructure<RECT>(m.LParam);
                WidgetSnapEngine.ApplySnap(this, ref rect, WidgetHostEngine.Instance.GetActiveWidgets());
                Marshal.StructureToPtr(rect, m.LParam, false);
            }
            else if (m.Msg == WM_EXITSIZEMOVE)
            {
                SnapOverlayWindow.Instance.ShowGuides(null, null);
                SaveWidgetState();
            }

            base.WndProc(ref m);
        }

        public void SaveWidgetState()
        {
            try
            {
                var configPath = GetConfigFilePath();
                Directory.CreateDirectory(Path.GetDirectoryName(configPath)!);

                var state = new WidgetState { WidgetId = WidgetId, X = Location.X, Y = Location.Y, Width = Width, Height = Height, IsLocked = IsLocked };
                File.WriteAllText(configPath, JsonSerializer.Serialize(state));
            }
            catch (IOException) { }
        }

        private void LoadWidgetState(int defaultX, int defaultY)
        {
            var configPath = GetConfigFilePath();
            if (File.Exists(configPath))
            {
                try
                {
                    var state = JsonSerializer.Deserialize<WidgetState>(File.ReadAllText(configPath));
                    if (state != null)
                    {
                        if (state.Width > 120 && state.Height > 80) Size = new Size(Math.Clamp(state.Width, 160, 1200), Math.Clamp(state.Height, 100, 900));
                        Location = ClampToAvailableScreen(new Point(state.X, state.Y));
                        IsLocked = state.IsLocked;
                        return;
                    }
                }
                catch (JsonException) { }
            }

            Location = ClampToAvailableScreen(new Point(defaultX, defaultY));
        }

        private Point ClampToAvailableScreen(Point location)
        {
            var screen = Screen.AllScreens.FirstOrDefault(s => s.WorkingArea.Contains(location)) ?? Screen.PrimaryScreen;
            if (screen == null) return location;
            var area = screen.WorkingArea;
            return new Point(Math.Clamp(location.X, area.Left, Math.Max(area.Left, area.Right - Width)), Math.Clamp(location.Y, area.Top, Math.Max(area.Top, area.Bottom - Height)));
        }

        private string GetConfigFilePath() =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "MotionDeskStudio", "widgets", $"{WidgetId}_config.json");

        private async System.Threading.Tasks.Task InitializeWebViewAsync()
        {
            try
            {
                if (IsDisposed) return;
                _webView = new WebView2 { Dock = DockStyle.Fill, DefaultBackgroundColor = Color.Transparent };
                Controls.Add(_webView);
                await _webView.EnsureCoreWebView2Async(await WebView2Support.CreateEnvironmentAsync());
                if (IsDisposed || _webView.CoreWebView2 == null) return;
                _webView.CoreWebView2.AddHostObjectToScript("motionDesk", new WidgetBridge(this));
                string htmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "widgets", WidgetId, "index.html");
                if (File.Exists(htmlPath)) _webView.CoreWebView2.Navigate(htmlPath);
            }
            catch (Exception ex)
            {
                if (!IsDisposed) Text = $"MotionDesk - {WidgetId}";
                System.Diagnostics.Debug.WriteLine($"WebView2 widget initialization failed: {ex}");
            }
        }

        private void ShowWidgetMenu(Control owner)
        {
            using var menu = new ContextMenuStrip();
            var lockItem = new ToolStripMenuItem(IsLocked ? "Unlock widget" : "Lock widget");
            lockItem.Click += (_, _) => { IsLocked = !IsLocked; SaveWidgetState(); };
            menu.Items.Add(lockItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Close widget", null, (_, _) => Close());
            menu.Show(owner, owner.PointToClient(Cursor.Position));
        }

        private Panel CreateNativePanel(string title, out Label values)
        {
            var panel = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(25, 25, 28), Padding = new Padding(14) };
            var titleLabel = new Label { Dock = DockStyle.Top, Height = 30, Text = title, Font = new Font("Segoe UI", 12, FontStyle.Bold), ForeColor = Color.White, Cursor = Cursors.SizeAll };
            titleLabel.MouseDown += (_, e) =>
            {
                if (e.Button == MouseButtons.Left && !IsLocked) BeginNativeDrag();
                else if (e.Button == MouseButtons.Right) ShowWidgetMenu(titleLabel);
            };
            panel.MouseDown += (_, e) => { if (e.Button == MouseButtons.Left && !IsLocked) BeginNativeDrag(); };
            values = new Label { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 11), ForeColor = Color.White };
            panel.Controls.Add(values); panel.Controls.Add(titleLabel); Controls.Add(panel);
            return panel;
        }

        private void InitializeNativeClock()
        {
            var panel = CreateNativePanel("Clock", out var values);
            values.TextAlign = ContentAlignment.MiddleCenter;
            values.Font = new Font("Segoe UI", 25, FontStyle.Bold);
            void Update() => values.Text = DateTime.Now.ToString("HH:mm:ss\n\ndddd, dd MMMM yyyy");
            Update();
            _nativeMonitorTimer = new System.Windows.Forms.Timer { Interval = 1000 };
            _nativeMonitorTimer.Tick += (_, _) => Update();
            _nativeMonitorTimer.Start();
        }

        private void InitializeNativeNetwork()
        {
            var panel = CreateNativePanel("Network", out var values);
            void Update()
            {
                var m = AdvancedSystemMonitorService.Instance.GetSnapshot();
                values.Text = $"Download   {m.NetworkDownKbps:0.0} KB/s\n\nUpload       {m.NetworkUpKbps:0.0} KB/s\n\nProcesses   {m.ProcessCount}";
            }
            Update();
            _nativeMonitorTimer = new System.Windows.Forms.Timer { Interval = 2000 };
            _nativeMonitorTimer.Tick += (_, _) => Update();
            _nativeMonitorTimer.Start();
        }

        private void InitializeNativeAudio()
        {
            var panel = CreateNativePanel("Audio Visualizer", out var values);
            values.TextAlign = ContentAlignment.MiddleCenter;
            values.Font = new Font("Segoe UI", 18, FontStyle.Bold);
            var audio = new AudioPeakService();
            void Update()
            {
                var peak = Math.Clamp(audio.GetPeak(), 0f, 1f);
                int bars = (int)Math.Round(peak * 20);
                values.Text = new string('█', bars).PadRight(20, '░') + $"\n\n{peak * 100:0}%";
            }
            Update();
            _nativeMonitorTimer = new System.Windows.Forms.Timer { Interval = 100 };
            _nativeMonitorTimer.Tick += (_, _) => Update();
            _nativeMonitorTimer.Start();
            FormClosed += (_, _) => audio.Dispose();
        }

        private void InitializeNativeWeather()
        {
            var panel = CreateNativePanel("Weather · Athens", out var values);
            values.Text = "Loading…";
            async void Update()
            {
                try
                {
                    var json = await WeatherService.GetWeatherJsonAsync();
                    using var doc = JsonDocument.Parse(json);
                    if (doc.RootElement.TryGetProperty("current_weather", out var current))
                    {
                        var temp = current.GetProperty("temperature").GetDouble();
                        var wind = current.GetProperty("windspeed").GetDouble();
                        values.Text = $"{temp:0.#} °C\n\nWind {wind:0.#} km/h\n\nUpdated {DateTime.Now:HH:mm}";
                    }
                    else values.Text = "Weather unavailable";
                }
                catch { values.Text = "Weather unavailable"; }
            }
            Update();
            _nativeMonitorTimer = new System.Windows.Forms.Timer { Interval = 900000 };
            _nativeMonitorTimer.Tick += (_, _) => Update();
            _nativeMonitorTimer.Start();
        }

        private void InitializeNativeSystemMonitor()
        {
            var panel = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(25, 25, 28), Padding = new Padding(14) };
            var title = new Label { Dock = DockStyle.Top, Height = 28, Text = "System Monitor", Font = new Font("Segoe UI", 12, FontStyle.Bold), ForeColor = Color.White, Cursor = Cursors.SizeAll };
            title.MouseDown += (_, e) => { if (e.Button == MouseButtons.Left && !IsLocked) BeginNativeDrag(); else if (e.Button == MouseButtons.Right) ShowWidgetMenu(title); };
            var values = new Label { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 11), ForeColor = Color.White };
            panel.Controls.Add(values); panel.Controls.Add(title); Controls.Add(panel);
            void Update()
            {
                var m = SystemMonitorService.Instance.GetSnapshot();
                values.Text = $"CPU     {m.CpuPercent:0.0}%\n\nRAM     {m.AvailableMemoryMb:0} MB free\n        {m.TotalMemoryMb:0} MB total";
            }
            Update();
            _nativeMonitorTimer = new System.Windows.Forms.Timer { Interval = 2000 };
            _nativeMonitorTimer.Tick += (_, _) => Update();
            _nativeMonitorTimer.Start();
        }

        [DllImport("user32.dll")] private static extern bool ReleaseCapture();
        [DllImport("user32.dll")] private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
    }

    public class WidgetState
    {
        public string WidgetId { get; set; } = string.Empty;
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public bool IsLocked { get; set; }
    }

    public sealed class WidgetSnapshot
    {
        public string WidgetId { get; set; } = string.Empty;
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public bool IsLocked { get; set; }
    }

    public class WidgetHostEngine
    {
        private static WidgetHostEngine? _instance;
        public static WidgetHostEngine Instance => _instance ??= new WidgetHostEngine();

        private readonly List<WidgetWindow> _activeWidgets = new();
        public IReadOnlyCollection<WidgetWindow> GetActiveWidgets() => _activeWidgets;

        public IReadOnlyList<WidgetSnapshot> GetSnapshots() => _activeWidgets
            .Where(w => !w.IsDisposed)
            .Select(w => new WidgetSnapshot { WidgetId = w.WidgetId, X = w.Location.X, Y = w.Location.Y, Width = w.Width, Height = w.Height, IsLocked = w.IsLocked })
            .ToArray();

        public void RestoreSnapshots(IEnumerable<WidgetSnapshot> snapshots)
        {
            CloseAll();
            foreach (var snapshot in snapshots.Where(s => !string.IsNullOrWhiteSpace(s.WidgetId)))
            {
                var widget = SpawnWidget(snapshot.WidgetId, snapshot.X, snapshot.Y, Math.Max(160, snapshot.Width), Math.Max(100, snapshot.Height));
                widget.IsLocked = snapshot.IsLocked;
                widget.SaveWidgetState();
            }
        }

        public void CloseAll()
        {
            foreach (var widget in new List<WidgetWindow>(_activeWidgets))
                if (!widget.IsDisposed) widget.Close();
            _activeWidgets.Clear();
        }

        public WidgetWindow SpawnWidget(string widgetId, int x, int y, int width, int height)
        {
            var existing = _activeWidgets.Find(w => w.WidgetId == widgetId);
            if (existing != null && !existing.IsDisposed)
            {
                existing.BringToFront();
                return existing;
            }

            var widgetWindow = new WidgetWindow(widgetId, x, y, width, height);
            _activeWidgets.Add(widgetWindow);
            widgetWindow.FormClosed += (s, e) => _activeWidgets.Remove(widgetWindow);
            widgetWindow.Show();
            return widgetWindow;
        }
    }
}
