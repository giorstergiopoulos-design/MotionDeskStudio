using System;
using System.Runtime.InteropServices;

namespace MotionDesk.Widgets
{
    // Ο κλασικός "trick" (Progman -> 0x052C -> WorkerW) για να τοποθετηθεί ένα παράθυρο
    // ακριβώς πίσω από τα εικονίδια της επιφάνειας εργασίας (DreamScene-style wallpapers).
    public static class WallpaperInterop
    {
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam, uint flags, uint timeout, out IntPtr result);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string? lpszClass, string? lpszWindow);

        [DllImport("user32.dll")]
        private static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        public static IntPtr FindDesktopWorkerW()
        {
            IntPtr progman = FindWindowEx(IntPtr.Zero, IntPtr.Zero, "Progman", null);
            if (progman == IntPtr.Zero) return IntPtr.Zero;

            // Ζητάει από το Progman να δημιουργήσει (αν δεν υπάρχει ήδη) ένα WorkerW πίσω από τα εικονίδια.
            SendMessageTimeout(progman, 0x052C, IntPtr.Zero, IntPtr.Zero, 0x0, 1000, out _);

            IntPtr workerw = IntPtr.Zero;
            EnumWindows((hwnd, lParam) =>
            {
                IntPtr shellView = FindWindowEx(hwnd, IntPtr.Zero, "SHELLDLL_DefView", null);
                if (shellView != IntPtr.Zero)
                {
                    // Το WorkerW-στόχος είναι το επόμενο αδερφό παράθυρο του WorkerW που περιέχει το SHELLDLL_DefView.
                    workerw = FindWindowEx(IntPtr.Zero, hwnd, "WorkerW", null);
                }
                return true;
            }, IntPtr.Zero);

            return workerw != IntPtr.Zero ? workerw : progman;
        }

        public static void AttachToDesktop(IntPtr windowHandle)
        {
            IntPtr target = FindDesktopWorkerW();
            if (target != IntPtr.Zero)
            {
                SetParent(windowHandle, target);
            }
        }
    }
}
