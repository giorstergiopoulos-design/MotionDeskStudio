using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MotionDesk.Widgets
{
    // Αναβίωση του Windows Flip 3D (Win+Tab στα Vista): στοίβα από ζωντανά DWM thumbnails
    // των ανοιχτών παραθύρων, με κλικ-για-ενεργοποίηση. Ενεργοποιείται με Ctrl+Alt+F.
    public class Flip3DOverlay : Form
    {
        private const int ThumbWidth = 280;
        private const int ThumbHeight = 175;
        private const int Overlap = 90;

        private readonly List<(IntPtr Hwnd, string Title, IntPtr ThumbId, Rectangle Bounds)> _entries = new();

        public Flip3DOverlay()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            TopMost = true;
            Bounds = SystemInformation.VirtualScreen;
            BackColor = Color.FromArgb(20, 20, 28);
            Opacity = 0.001; // αρχικά αόρατο μέχρι να γίνει set το πραγματικό opacity μετά τα thumbnails

            KeyPreview = true;
            KeyDown += (s, e) => { if (e.KeyCode == Keys.Escape) Close(); };
            Click += (s, e) => Close();
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            Opacity = 0.88;
            BuildThumbnails();
        }

        private void BuildThumbnails()
        {
            var windows = EnumerateCandidateWindows();

            int startX = (Width - (windows.Count * (ThumbWidth - Overlap) + Overlap)) / 2;
            int baseY = (Height - ThumbHeight) / 2;
            int index = 0;

            foreach (var hwnd in windows)
            {
                if (DwmRegisterThumbnail(Handle, hwnd, out IntPtr thumbId) != 0) continue;

                int x = startX + index * (ThumbWidth - Overlap);
                int y = baseY - Math.Abs(index - windows.Count / 2) * 6; // ελαφριά καμπύλη "3D στοίβα"
                var rect = new Rectangle(x, y, ThumbWidth, ThumbHeight);

                var props = new DWM_THUMBNAIL_PROPERTIES
                {
                    dwFlags = DWM_TNP_RECTDESTINATION | DWM_TNP_VISIBLE | DWM_TNP_OPACITY,
                    rcDestination = new RECT { Left = rect.Left, Top = rect.Top, Right = rect.Right, Bottom = rect.Bottom },
                    fVisible = true,
                    opacity = 255
                };
                DwmUpdateThumbnailProperties(thumbId, ref props);

                _entries.Add((hwnd, GetWindowTitle(hwnd), thumbId, rect));
                index++;
            }

            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using var font = new Font("Segoe UI", 9f);
            using var brush = new SolidBrush(Color.White);
            using var pen = new Pen(Color.FromArgb(150, 255, 255, 255), 1.5f);

            foreach (var entry in _entries)
            {
                e.Graphics.DrawRectangle(pen, entry.Bounds);
                e.Graphics.DrawString(entry.Title, font, brush, entry.Bounds.X, entry.Bounds.Bottom + 4);
            }

            using var hint = new Font("Segoe UI", 10f, FontStyle.Bold);
            e.Graphics.DrawString("Κλικ σε ένα παράθυρο για ενεργοποίηση  •  Esc για έξοδο", hint, brush, 20, 20);
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            foreach (var entry in _entries)
            {
                if (entry.Bounds.Contains(e.Location))
                {
                    SetForegroundWindow(entry.Hwnd);
                    Close();
                    return;
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            foreach (var entry in _entries)
                DwmUnregisterThumbnail(entry.ThumbId);
            base.OnFormClosing(e);
        }

        private List<IntPtr> EnumerateCandidateWindows()
        {
            var result = new List<IntPtr>();
            EnumWindows((hwnd, _) =>
            {
                if (!IsWindowVisible(hwnd)) return true;
                if (GetWindowTextLength(hwnd) == 0) return true;

                int exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
                if ((exStyle & WS_EX_TOOLWINDOW) != 0) return true;

                result.Add(hwnd);
                return true;
            }, IntPtr.Zero);
            return result;
        }

        private static string GetWindowTitle(IntPtr hwnd)
        {
            int len = GetWindowTextLength(hwnd);
            var sb = new System.Text.StringBuilder(len + 1);
            GetWindowText(hwnd, sb, sb.Capacity);
            return sb.ToString();
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct DWM_THUMBNAIL_PROPERTIES
        {
            public int dwFlags;
            public RECT rcDestination;
            public RECT rcSource;
            public byte opacity;
            public bool fVisible;
            public bool fSourceClientAreaOnly;
        }

        private const int DWM_TNP_RECTDESTINATION = 0x1;
        private const int DWM_TNP_OPACITY = 0x4;
        private const int DWM_TNP_VISIBLE = 0x8;

        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_TOOLWINDOW = 0x00000080;

        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("dwmapi.dll")] private static extern int DwmRegisterThumbnail(IntPtr dest, IntPtr src, out IntPtr thumb);
        [DllImport("dwmapi.dll")] private static extern int DwmUnregisterThumbnail(IntPtr thumb);
        [DllImport("dwmapi.dll")] private static extern int DwmUpdateThumbnailProperties(IntPtr thumb, ref DWM_THUMBNAIL_PROPERTIES props);

        [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
        [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hWnd);
        [DllImport("user32.dll")] private static extern int GetWindowTextLength(IntPtr hWnd);
        [DllImport("user32.dll", CharSet = CharSet.Auto)] private static extern int GetWindowText(IntPtr hWnd, System.Text.StringBuilder text, int count);
        [DllImport("user32.dll")] private static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        [DllImport("user32.dll")] private static extern bool SetForegroundWindow(IntPtr hWnd);
    }

    public static class Flip3DEngine
    {
        public static void Show()
        {
            new Flip3DOverlay().Show();
        }
    }
}
