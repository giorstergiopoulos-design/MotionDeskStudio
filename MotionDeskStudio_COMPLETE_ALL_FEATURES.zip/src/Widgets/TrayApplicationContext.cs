using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using MotionDesk.Services;
using MotionDesk.UI;

namespace MotionDesk.Widgets
{
    public class TrayApplicationContext : ApplicationContext
    {
        private readonly NotifyIcon _trayIcon = null!;
        private MainWindow? _mainWindow;
        private readonly HotkeyManager _hotkeys = new();
        private readonly ToolStripMenuItem _wallpaperToggleItem;
        private bool _wallpaperEnabled;

        public TrayApplicationContext()
        {
            // Δημιουργία Context Menu για το Tray Icon
            ContextMenuStrip contextMenu = new ContextMenuStrip();
            contextMenu.Items.Add("Άνοιγμα Manager", null, (s, e) => ShowMainWindow());
            contextMenu.Items.Add("Ρυθμίσεις...", null, (s, e) => ShowMainWindow());
            contextMenu.Items.Add(new ToolStripSeparator());

            contextMenu.Items.Add("Νέα DeskZone", null, (s, e) => AddDeskZone());

            _wallpaperToggleItem = new ToolStripMenuItem("Ζωντανή Επιφάνεια Εργασίας (Wallpaper)");
            _wallpaperToggleItem.Click += (s, e) => ToggleWallpaper();
            contextMenu.Items.Add(_wallpaperToggleItem);
            contextMenu.Items.Add("Επιλογή Βίντεο Wallpaper...", null, (s, e) => ChooseWallpaperVideo());

            contextMenu.Items.Add("Flip 3D  (Ctrl+Alt+F)", null, (s, e) => Flip3DEngine.Show());

            ToolStripMenuItem gridSnapItem = new ToolStripMenuItem("Ενεργοποίηση Grid Snap");
            gridSnapItem.Checked = WidgetSnapEngine.EnableGridSnap;
            gridSnapItem.Click += (s, e) => {
                WidgetSnapEngine.EnableGridSnap = !gridSnapItem.Checked;
                gridSnapItem.Checked = WidgetSnapEngine.EnableGridSnap;
            };
            contextMenu.Items.Add(gridSnapItem);

            ToolStripMenuItem startupItem = new ToolStripMenuItem("Αυτόματη Εκκίνηση (Startup)");
            startupItem.Checked = StartupManager.IsStartupEnabled();
            startupItem.Click += (s, e) => {
                bool newState = !startupItem.Checked;
                StartupManager.SetStartup(newState);
                startupItem.Checked = newState;
            };
            contextMenu.Items.Add(startupItem);

            contextMenu.Items.Add(new ToolStripSeparator());
            contextMenu.Items.Add("Έξοδος", null, (s, e) => {
                _hotkeys.Dispose();
                _trayIcon.Visible = false;
                Application.Exit();
            });

            // Αρχικοποίηση NotifyIcon
            _trayIcon = new NotifyIcon()
            {
                Icon = LoadTrayIcon(),
                ContextMenuStrip = contextMenu,
                Text = "MotionDesk Studio (DeskZones)",
                Visible = true
            };

            _trayIcon.DoubleClick += (s, e) => ShowMainWindow();

            _hotkeys.RegisterCtrlAlt('F', () => Flip3DEngine.Show());

            // Restore lightweight persistent preferences before showing the manager.
            var appSettings = AppSettings.Load();
            WidgetSnapEngine.EnableGridSnap = appSettings.GridSnap;
            WidgetSnapEngine.SnapThreshold = Math.Clamp(appSettings.SnapThreshold, 5, 50);
            WidgetSnapEngine.GridSize = Math.Clamp(appSettings.GridSize, 5, 100);
            _wallpaperEnabled = WallpaperHostEngine.Instance.IsEnabled;

            if (appSettings.StartWallpaperWithWindows)
            {
                WallpaperHostEngine.Instance.Enable();
                _wallpaperEnabled = true;
            }

            ShowMainWindow();
        }

        private void ShowMainWindow()
        {
            if (_mainWindow == null || _mainWindow.IsDisposed)
            {
                _mainWindow = new MainWindow();
                _mainWindow.FormClosed += (s, e) => _mainWindow = null;
                _mainWindow.Show();
            }
            else
            {
                if (_mainWindow.WindowState == FormWindowState.Minimized)
                    _mainWindow.WindowState = FormWindowState.Normal;

                _mainWindow.Show();
                _mainWindow.BringToFront();
                _mainWindow.Activate();
            }
        }

        private void ToggleWallpaper()
        {
            _wallpaperEnabled = !_wallpaperEnabled;
            _wallpaperToggleItem.Checked = _wallpaperEnabled;

            if (_wallpaperEnabled)
                WallpaperHostEngine.Instance.Enable();
            else
                WallpaperHostEngine.Instance.Disable();
        }

        private void ChooseWallpaperVideo()
        {
            using var dialog = new OpenFileDialog
            {
                Filter = "Βίντεο (*.mp4;*.webm;*.mov;*.mkv)|*.mp4;*.webm;*.mov;*.mkv|Όλα τα αρχεία (*.*)|*.*",
                Title = "Επιλογή Βίντεο Wallpaper"
            };

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                if (!_wallpaperEnabled) ToggleWallpaper();
                WallpaperHostEngine.Instance.SetVideo(dialog.FileName);
            }
        }

        private static Icon LoadTrayIcon()
        {
            var path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "MotionDesk.ico");
            return File.Exists(path) ? new Icon(path) : SystemIcons.Application;
        }

        private int _zoneCounter;

        private void AddDeskZone()
        {
            _zoneCounter++;
            string zoneId = $"zone{_zoneCounter}";
            DeskZoneHostEngine.Instance.SpawnZone(zoneId, "Νέα DeskZone", 450 + _zoneCounter * 20, 100 + _zoneCounter * 20, 260, 220);
        }
    }
}
